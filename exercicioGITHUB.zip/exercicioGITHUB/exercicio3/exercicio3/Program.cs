﻿using System;

namespace exercicio3
{
    class Program
    {
        static void Main(string[] args)
        {
            Double A;
            Double B;
            Double C;
          

            Console.WriteLine("Digite o valor de A");
            Console.WriteLine("Digite o valor de B");

            A = Double.Parse(Console.ReadLine());
            B = Double.Parse(Console.ReadLine());

            C = A;
            A = B;
            B = C;
            Console.WriteLine("Digite o valor de A : " + A );
            Console.WriteLine("Digite o valor de B : " + B);

            Console.ReadKey();

 
 

        }
    }
}
