﻿using System;

namespace exercicio2
{
    class Program
    {
        static void Main(string[] args)
        {
            // Cálculo de salário//

            Double aulas;
            Double valor_horas;
            Double inss;
            Double Salario;

            Console.WriteLine("Digite o numero de aulas");
            Console.WriteLine("Digite o valor da hora aula");
            Console.WriteLine("Digite o desconto inss");

            aulas = Double.Parse(Console.ReadLine());
            valor_horas = Double.Parse(Console.ReadLine());
            inss = Double.Parse(Console.ReadLine());

            Salario = (aulas * valor_horas) * (1 - inss / 100);

            Console.WriteLine("O salário é " + Salario);






        }
    }
}
