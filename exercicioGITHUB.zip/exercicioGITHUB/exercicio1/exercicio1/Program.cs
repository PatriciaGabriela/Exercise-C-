﻿using System;

namespace exercicio1
{
    class Program
    {
        static void Main(string[] args)
        {
            Double area;
            Double raio;

            Console.Write("Digite o valor do raio");
            raio = Double.Parse(Console.ReadLine());

            area = raio * raio * 3.14;

            Console.Write("O resultado da área é " + area);
            Console.ReadKey();


        }
    }
}
