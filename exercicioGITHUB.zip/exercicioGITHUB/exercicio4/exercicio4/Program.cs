﻿using System;

namespace exercicio4
{
    class Program
    {
        static void Main(string[] args)
        {
            Double A;
            Double B;
            Double R1;
            Double R2;
            Double R3;
            Double R4;

            Console.WriteLine("Digite o valor de A");
            Console.WriteLine("Digite o valor de B");

            A = Double.Parse(Console.ReadLine());
            B = Double.Parse(Console.ReadLine());

            R1 = A + B;
            R2 = A - B;
            R3 = A * B;
            R4 = A / B;

            Console.WriteLine("Escreva o valor de R1 " + R1);
            Console.WriteLine("Escreva o valor de R2 " + R2);
            Console.WriteLine("Escreva o valor de R3 " + R3);
            Console.WriteLine("Escreva o valor de R4 " + R4);

            Console.ReadKey();


        }
    }
}
