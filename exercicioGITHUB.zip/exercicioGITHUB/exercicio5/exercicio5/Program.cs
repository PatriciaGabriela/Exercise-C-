﻿using System;

namespace exercicio5
{
    class Program
    {
        static void Main(string[] args)
        {
            //Efetuar o cálculo do valor de uma prestação em atraso//

            Double Prestacao;
            Double Valor;
            Double Taxa;
            Double Tempo;

            Console.WriteLine("Digite o valor da prestação");
            Valor = Double.Parse(Console.ReadLine());
            Console.WriteLine("Digite o valor da taxa");
            Taxa = Double.Parse(Console.ReadLine());
            Console.WriteLine("Digite o tempo");
            Tempo = Double.Parse(Console.ReadLine());

            Prestacao = Valor + (Valor * (Taxa / 100) * Tempo);

            Console.WriteLine("A prestação em atraso é " + Prestacao);
            Console.ReadKey();

        }
    }
}