﻿using System;

namespace exercicios7
{
    class Program
    {
        static void Main(string[] args)
        {
            //Calcule a área de um triângulo//

            Double Area;
            Double Base;
            Double Altura;

            Console.WriteLine("Digite o valor da prestação");
            Base = Double.Parse(Console.ReadLine());
            Console.WriteLine("Digite o valor da taxa");
            Altura = Double.Parse(Console.ReadLine());


            Area = Base * Altura / 2;

            Console.WriteLine("A área do triângulo é " + Area);
            Console.ReadKey();
        }
    }
}
