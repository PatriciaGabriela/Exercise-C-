﻿using System;

namespace exercicios6
{
    class Program
    {
        static void Main(string[] args)
        {
            //Calcule a área de um retângulo//

            Double Area;
            Double Base;
            Double Altura;     

            Console.WriteLine("Digite o valor da prestação");
            Base = Double.Parse(Console.ReadLine());
            Console.WriteLine("Digite o valor da taxa");
            Altura = Double.Parse(Console.ReadLine());


            Area = Base * Altura;

            Console.WriteLine("A área do retângulo é " + Area);
            Console.ReadKey();
        }
    }
}
